"""RB-SQMC model components."""
